$(function() {
	
	var h_hght = 59; // высота шапки
	var elem = $('section.menu');
	var top = $(this).scrollTop();
	if(top > h_hght){
		elem.removeClass('top-block');
	}           
		
	$(window).scroll(function(){
		top = $(this).scrollTop();
		
		if (top > h_hght) {
			elem.addClass('top-block');
		} else {
			elem.removeClass('top-block');
		}
	});	
	
	function onNavbar() {
		if (window.innerWidth >= 768) {
			$(document)
				.on('mouseover', '.navbar-default .dropdown', function(){
					$('.dropdown-toggle', this).next('.dropdown-menu').show();
				})
				.on('mouseout', '.navbar-default .dropdown', function(){
					$('.dropdown-toggle', this).next('.dropdown-menu').hide();
				})
				.on('click', '.dropdown-toggle', function(){
					if ($(this).next('.dropdown-menu').is(':visible')) {
						window.location = $(this).attr('href');
					}
				});
		} else {
			$('.navbar-default .dropdown').off('mouseover').off('mouseout');
		}
	}


	function navRollup(){
		//$(".roll-up").removeClass("d-lg-block");
		var navWidth = $(".navbar").outerWidth(true) - $(".navbar-brand").outerWidth(true);
		if($(".navbar .btn").length) {
			navWidth = navWidth - $(".navbar .btn").outerWidth(true);
		}
		var navWidthItemsSum = $(".roll-up").outerWidth();
		var hideNext = false;


		$(".navbar-nav .nav-item").each(function( index ) {
			//if ($(this).hasClass('dropdown')) return;

			var idItem = $(this).attr("data-menuitemid");

			if ($(this).outerWidth()+navWidthItemsSum <= navWidth && hideNext == false){
				$(this).removeClass("d-lg-none");
				$("#menuitemid-"+idItem).addClass("d-lg-none");

				$(".roll-up").removeClass("d-lg-block").addClass("load");
			}

			if(index == $(".navbar-nav .nav-item").length - 1) {
				$(".roll-up").addClass("d-lg-none").removeClass("load");
			}

			if ($(this).outerWidth()+navWidthItemsSum > navWidth){
				if ($(this).hasClass("roll-up")===false){
					$(this).addClass("d-lg-none");
				}
				$("#menuitemid-"+idItem).removeClass("d-lg-none");
				$(".roll-up").addClass("d-lg-block").removeClass("load");

				hideNext = true;
			}

			navWidthItemsSum = navWidthItemsSum + $(this).outerWidth();
		});
	}

	$(window).resize(function() {
		onNavbar();
		navRollup();
	});

	$(document).ready(function() {
		setTimeout(function() {
			onNavbar();
			navRollup();
		}, 300);
    });
});

