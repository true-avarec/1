var mfoApp = angular.module('mfoMessage', []);
mfoApp.controller('messagesList', function ($scope, $http) {
    $scope.fields = {'VIEW_ALL' : false};

    $scope.validateFile = function(file)
    {
        if($scope.fields.FILES.length>=2)
            return "TOO_MANY_FILES";
        return true;
    }
});

$(document).ready(function() {
    $(document).on('click', '.scroll-to-message', function (e) {
        setInterval(toMessage(), 1000);
    });

    function toMessage() {
        $([document.documentElement, document.body]).animate({
            scrollTop: $("#firstScrollMessage").offset().top
        }, 300);
    }
});