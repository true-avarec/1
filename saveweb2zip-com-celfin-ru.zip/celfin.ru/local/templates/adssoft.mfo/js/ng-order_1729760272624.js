var mfoApp = angular.module('mfoOrder', ['ui.mask', 'ui.select2', 'ngFlatDatepicker']);

mfoApp.controller('calcController', function ($scope) {

}).directive('calcAjax', function($compile, $http) {
    return function(scope, element) {
        element.addClass('loading');

        var url = window.location.href;
        url = url.split('#')[0];
        $http.get(url.split('?')[0] + '?ajax_form_request=Y')
            .then(function(response) {
                html = response.data;
                element.html(html).removeClass('loading');
                $compile(element.contents())(scope);
            });
    }
});