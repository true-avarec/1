/**
 * Enhanced Select2 Dropmenus
 *
 * @AJAX Mode - When in this mode, your value will be an object (or array of objects) of the data used by Select2
 *     This change is so that you do not have to do an additional query yourself on top of Select2's own query
 * @params [options] {object} The configuration options passed to $.fn.select2(). Refer to the documentation
 */
/* global angular */
angular.module('ui.select2', []).value('uiSelect2Config', {}).directive('uiSelect2', ['uiSelect2Config', '$timeout', '$parse', function (uiSelect2Config, $timeout, $parse) {
    var options = {},
        NGOPTIONS_REGEXP = /^\s*(.*?)(?:\s+as\s+(.*?))?\s+for\s+(?:([\$\w][\$\w\d]*))\s+in\s+(.*?)(?:\s+track\s+by\s+(.*?))?$/;
    if (uiSelect2Config) {
        angular.extend(options, uiSelect2Config);
    }

    $(document).on('keyup', '.select2-search__field', function(oEvent) {
        if ($('.select2-results__options li:first-child').html() === '') {
                $('.select2-results__options li:first-child').removeClass ('active');
        } else if ($('.select2-results__options li:first-child').html() !== 'No results found') {
            $('.select2-results__options li:first-child').addClass('active');
        }
    });

    $(document).on('click', '.select2-selection', function(oEvent) {
        if ($('.select2-results__options li:first-child').html() !== '') {
            $('.select2-results__options li:first-child').addClass('active');
        }
    });

    return {
        require: '?ngModel',
        compile: function (tElm, tAttrs) {
            var watch,
                repeatOption,
                repeatAttr,
                isSelect = tElm.is('select'),
                ngOptions,
                hasNoNgOptions = isSelect && !tAttrs.ngOptions,
                isMultiple = (tAttrs.multiple !== undefined),
                parseNgOptions = function parseNgOptions(input) {
                console.log(NGOPTIONS_REGEXP);
                    var match = input.match(NGOPTIONS_REGEXP);
                    if (!match) {
                        throw 'invalid ngOptions regexp';
                    }

                    return {
                        itemName: match[3],
                        source: $parse(match[4]),
                        sourceName: match[4],
                        viewMapper: $parse(match[2] || match[1]),
                        modelMapper: $parse(match[1]),
                        trackMapper: $parse(match[5])
                    };
                };

            // Enable watching of the options dataset if in use
            if (tElm.is('select')) {
                repeatOption = tElm.find('option[ng-repeat], option[data-ng-repeat]');

                if (repeatOption.length) {
                    repeatAttr = repeatOption.attr('ng-repeat') || repeatOption.attr('data-ng-repeat');
                    watch = jQuery.trim(repeatAttr.split('|')[0]).split(' ').pop();
                }
            }

            return function (scope, elm, attrs, controller) {
                // instance-specific options
                var opts = angular.extend({}, options, scope.$eval(attrs.uiSelect2));

                if (isSelect) {
                    // Use <select multiple> instead
                    delete opts.multiple;
                    delete opts.initSelection;
                } else if (!isSelect && opts.multiple) {
                    isMultiple = true;
                } else if (isMultiple) {
                    opts.multiple = true;
                }

                if (attrs.ngOptions) {
                    ngOptions = parseNgOptions(attrs.ngOptions);
                }

                if (controller) {
                    // Watch the model for programmatic changes
                    controller.$render = function () {
                        if (isSelect && hasNoNgOptions) {
                            elm.select2('val', controller.$viewValue);
                        } else {
                            if (isMultiple) {
                                if (!controller.$viewValue) {
                                    elm.select2('data', []);
                                } else if (angular.isArray(controller.$viewValue)) {
                                    if (ngOptions) {
                                        elm.select2('data',
                                            $parse(ngOptions.source)(scope).filter(function (item) {
                                                return controller.$viewValue.indexOf(item) >= 0;
                                            }).map(function (item) {
                                                var o = {};
                                                o[ngOptions.itemName] = item;
                                                return {text: ngOptions.viewMapper(o), id: ngOptions.trackMapper(o) || item.$$hashKey};
                                            }));
                                    } else {
                                        elm.select2('data', controller.$viewValue);
                                    }
                                } else {
                                    elm.select2('val', controller.$viewValue);
                                }
                            } else {
                                if (angular.isObject(controller.$viewValue)) {
                                    if (ngOptions) {
                                        elm.select2('data',
                                            $parse(ngOptions.source)(scope).filter(function (item) {
                                                return controller.$viewValue === item;
                                            }).map(function (item) {
                                                var o = {};
                                                o[ngOptions.itemName] = item;
                                                return {text: ngOptions.viewMapper(o), id: ngOptions.trackMapper(o) || item.$$hashKey};
                                            }));
                                    } else {
                                        elm.select2('data', controller.$viewValue);
                                    }
                                } else if (!controller.$viewValue) {
                                    elm.select2('data', null);
                                } else {
                                    elm.select2('val', controller.$viewValue);
                                }
                            }
                        }
                    };

                    // Watch the options dataset for changes
                    if (watch) {
                        scope.$watch(watch, function (newVal, oldVal, scope) {
                            if (!newVal) return;
                            // Delayed so that the options have time to be rendered
                            $timeout(function () {
                                elm.select2('val', controller.$viewValue);
                                // Refresh angular to remove the superfluous option
                                elm.trigger('change');
                            });
                        });
                    }

                    // Update valid and dirty statuses
                    controller.$parsers.push(function (value) {
                        var div = elm.prev();
                        div
                            .toggleClass('ng-invalid', !controller.$valid)
                            .toggleClass('ng-valid', controller.$valid)
                            .toggleClass('ng-invalid-required', !controller.$valid)
                            .toggleClass('ng-valid-required', controller.$valid)
                            .toggleClass('ng-dirty', controller.$dirty)
                            .toggleClass('ng-pristine', controller.$pristine);
                        return value;
                    });

                    // Sync items in select2's val array with what we have in the model and select2's data array
                    var syncValues = function syncValues() {
                        var newData = [];
                        var newView = [];
                        var data = elm.select2('data');
                        var vals = elm.select2('val');
                        var i;
                        for (i = 0;i < data.length;i++) {
                            if (vals.indexOf('' + data[i].id) >= 0) {
                                newData.push(data[i]);
                            }
                        }
                        for (i = 0;i < controller.$viewValue.length;i++) {
                            if (vals.indexOf('' + controller.$viewValue[i].id) >= 0) {
                                newView.push(controller.$viewValue[i]);
                            }
                        }
                        elm.select2('data', newData);
                        controller.$setViewValue(newView);
                    };

                    elm.bind("select2-removed", function (evt) {
                        if (evt.val && isMultiple) {
                            syncValues();
                        }
                    });

                    if (!isSelect) {
                        // Set the view and model value and update the angular template manually for the ajax/multiple select2.
                        elm.bind("change", function () {
                            if (scope.$$phase) {
                                return;
                            }
                            // Sync the elements in 'val' with the ones in 'data'
                            scope.$apply(function () {
                                if (isMultiple) {
                                    syncValues();
                                }
                                controller.$setViewValue(elm.select2('data'));
                            });
                        });

                        if (opts.initSelection) {
                            var initSelection = opts.initSelection;
                            opts.initSelection = function (element, callback) {
                                initSelection(element, function (value) {
                                    controller.$setViewValue(value);
                                    callback(value);
                                });
                            };
                        }
                    }
                }

                attrs.$observe('disabled', function (value) {
                    elm.select2('enable', !value);
                });

                attrs.$observe('readonly', function (value) {
                    elm.select2('readonly', !!value);
                });

                if (attrs.ngMultiple) {
                    scope.$watch(attrs.ngMultiple, function (newVal) {
                        elm.select2(opts);
                    });
                }

                var addFn = attrs.uiSelect2Add;
                if (addFn) {
                    addFn = $parse(addFn);
                    elm.on('select2-selecting', function (event) {
                        scope.$apply(function () {
                            addFn(scope, {$event: event});
                        });
                    });
                }

                var removeFn = attrs.uiSelect2Remove;
                if (removeFn) {
                    removeFn = $parse(removeFn);
                    elm.on('select2-removing', function (event) {
                        scope.$apply(function () {
                            removeFn(scope, {$event: event});
                        });
                    });
                }


                // Initialize the plugin late so that the injected DOM does not disrupt the template compiler
                $timeout(function () {
                    elm.select2(opts);

                    // Set initial value - I'm not sure about this but it seems to need to be there
                    elm.val(controller.$viewValue);
                    // important!
                    controller.$render();

                    // Not sure if I should just check for !isSelect OR if I should check for 'tags' key
                    if (!opts.initSelection && !isSelect)
                        controller.$setViewValue(elm.select2('data'));
                });
            };
        }
    };
}]);