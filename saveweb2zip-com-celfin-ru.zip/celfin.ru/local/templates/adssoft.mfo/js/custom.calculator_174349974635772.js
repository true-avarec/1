$(document).ready(function() {

    //Калькулятор кредита
	function getActualSum(sKey) {
        return $('#inputSumRange').attr(sKey);
    }

    function getActualDays(sKey) {
        return $('#inputDaysRange').attr(sKey);
    }

    if ($(".calculator-percent").length) {
        var inputSum = "#inputSum",
            inputSumRange = "#inputSumRange",
            inputDays = "#inputDays",
            inputDaysRange = "#inputDaysRange",
            inputPercent = "#inputPercent",
            inputReference = ".inputReference",
            inputTermType = "#inputTermType",
            inputTermTypePercent = "#inputTermTypePercent";

        let minDays = $(inputDaysRange).attr('min');
        let maxDays = $(inputDaysRange).attr('max');
        let minSum = $(inputSumRange).attr('min');
        let maxSum = $(inputSumRange).attr('max');

        $(document)
            /*.on("keyup", inputSum, function () {
                minSum = getActualSum('min');
                maxSum = getActualSum('max');

                $(inputSumRange).val(clamp(this.value, minSum, maxSum));
                calculatorUpdate('sum');
            })
            */
			.on("blur", inputSum, function () {
                minSum = getActualSum('min');
                maxSum = getActualSum('max');

                $(this).val(clamp(this.value, minSum, maxSum));
                calculatorUpdate('sum');
            })

			.on("input", inputSumRange, function () {
                minSum = getActualSum('min');
                maxSum = getActualSum('max');

                $(inputSum).val(clamp(this.value, minSum, maxSum));
                calculatorUpdate('sum');
            })
            /*
			.on("keyup", inputDays, function () {
                return false;
				minDays = getActualDays('min');
                maxDays = getActualDays('max');

                $(inputDaysRange).val(clamp(this.value, minDays, maxDays));
                calculatorUpdate('days');
            })
			*/
			.on("keydown", inputDays, function () {
                return false;
            })

			.on("blur", inputDays, function () {
				minDays = getActualDays('min');
                maxDays = getActualDays('max');

                $(this).val(clamp(this.value, minDays, maxDays));
                calculatorUpdate('days');
            })

			.on("input", inputDaysRange, function () {
                minDays = getActualDays('min');
                maxDays = getActualDays('max');

                $(inputDays).val(clamp(this.value, minDays, maxDays));
                calculatorUpdate('days');
            })
            /**/
			.on("change", inputReference, productChange)
            .on("loadcalc", document, function() {
                /**
                 * При завершении загрузки калькулятора, запускаем пересчет
                 * setTimeout(productChange, 2000); не нужен, так как  теперь мы точно значем,
                 * что свежие данные загружены
                 */
                productChange();
            });

        productChange();
        //setTimeout(calculatorUpdate, 0);

        if(typeof BX !== 'undefined') {
            BX.addCustomEvent('onAjaxSuccess', productChange);
        }
    }

    function productChange() {
        if (!$(".inputReference:checked").length) {
            $(".inputReference:first").prop('checked', true)
        }
        $product = $(".inputReference:checked");
        minSum = $product.data('inputsumMin');
        maxSum = $product.data('inputsumMax');
        minDays = $product.data('inputdaysMin');
        maxDays = $product.data('inputdaysMax');
        intervalPercentName = $product.data('intervalPercentName');
        var percent = $product.data('inputpercent'),
            stepSum = (maxSum - minSum) / 50,
            stepDays = Math.max((maxDays - minDays) / 50, 1),
            days = clamp($(inputDays).val(), minDays, maxDays),
            sum = clamp($(inputSum).val(), minSum, maxSum);
        if (stepSum<500) stepSum = 500;
        if (stepSum>500) stepSum = 1000;

        $(inputSumRange).attr({ 'min': minSum, 'max': maxSum, 'step': stepSum }).val(sum);
        $(inputSumRange).siblings('.from').html("от " + minSum);
        $(inputSumRange).siblings('.to').html("до " + maxSum);
        $(inputDaysRange).attr({ 'min': minDays, 'max': 42, 'step': 7 }).val(days);
        $(inputDaysRange).siblings('.from').html("от 7 дней");
        $(inputDaysRange).siblings('.to').html("до 24 нед.");

        $(inputDays).val(7);
        $(inputSum).val(sum);

        $('.calculator-percent-interval').tooltip('dispose');
        if(intervalPercentName) {
            $(".calculator-percent-interval").text(intervalPercentName);
            $(".calculator-percent-interval-text").show();
            $(".calculator-percent-text").hide();
            $('.calculator-percent-interval').tooltip( {
                "title": intervalPercentName,
                "container": 'body'
            });
        } else {
            $(".calculator-percent").text(percent);
            $(".calculator-percent-text").show();
            $(".calculator-percent-interval-text").hide();
        }

        $(inputPercent).val(percent);
        $(inputTermType).val($product.data('termtypeTerm'));
        $(inputTermTypePercent).val($product.data('termtypePercent'));

        calculatorUpdate();
    }

    function calculatorUpdate(inptype='') { // по хорошему сделать один метод для займа и сбережения
        var termReference = {
            'day' : ['день', 'дня', 'дней'],
			'week' : ['неделя','недели','недель'],
            'month' : ['месяц', 'месяца', 'месяцев'],
            'year' : ['год', 'года', 'лет'],
        };

        var termReferenceShort = {
            'day' : 'день',
			'week': 'нед.',
            'month' : 'мес.',
            'year' : 'год',
        };

        var term = parseInt($(inputDays).val());
        var sum = parseInt($(inputSum).val());
        var monthly = 0;


		sum=Math.round(sum/1000)*1000;
		if (sum==0) sum=5000;
		$("#inputSum").val(sum);
		$("#inputSumRange").val(sum);

		vterm=$("#inputDaysRange").val();
		//console.log('inptype: '+inptype);

		if (inptype!=''){
		//console.log('sum1: '+sum+'; term: '+term+'; vterm: '+vterm);			
			if (inptype=='sum'){
				//console.log('u1');
				$("#inputDays").val(vterm);
				$("#inputDaysRange").val(vterm);				

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');				
			}
			
/*			
			if (inptype=='sum' && (sum>30000 && vterm<=28)){
				console.log('u1');
				$("#inputDays").val(35);
				$("#inputDaysRange").val(35);

				term=35;
				vterm=35;
				$('#product_1').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');
			}
			else if (inptype=='sum' && (sum<31000 && vterm>=35)){
				console.log('u2');

			}
*/
			if (inptype=='days'){
				$("#inputDays").val(vterm);
				$("#inputDaysRange").val(vterm);				
				
				if (term>28){
					$('#product_1').prop('checked', true);					
				}
				else{
					$('#product_0').prop('checked', true);					
				}

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');				
			}

/*
			if (inptype=='days' && (term>28 && sum<=30000)){
				console.log('u3');

				$("#inputDays").val(term);
				$("#inputDaysRange").val(term);

			
				$('#product_1').prop('checked', true);

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');					
			}
			else if (inptype=='days' && (vterm<35 && sum>30000)){
				console.log('u4');
				sum=30000;
				$("#inputSum").val(30000);
				$("#inputSumRange").val(30000);
				$('#product_0').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_day');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum100');
			}
			else if (inptype=='days' && (vterm<35 && sum<=30000)){
				console.log('u13');
				$("#inputSum").val(sum);
				$("#inputSumRange").val(sum);
				$('#product_0').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_day');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum100');
			}
*/			
		}
		else {
			//console.log('u5');
			$("#inputDaysRange").val($("#inputDaysRangeHid").val());
			$("#inputDays").val($("#inputDaysHid").val());
			$("#inputSumRange").val($("#inputSumHid").val());
			$("#inputSum").val($("#inputSumHid").val());
			vterm=$("#inputDaysRange").val();
			termType = $("input#inputTermType").val();
		//console.log('sum2: '+sum+'; term: '+term+'; vterm: '+vterm);			
			if (vterm < 35){
				//console.log('u11');
				$("#inputDays").val(vterm);
				$("#inputDaysRange").val(vterm);
				term=vterm;
				vterm=vterm;
				$('#product_0').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');				
				
			}
			else if (vterm >= 35){
				//console.log('u12');
				$("#inputDays").val(vterm);
				$("#inputDaysRange").val(vterm);
				term=vterm;
				vterm=vterm;
				$('#product_1').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');					
			}

/*
			if (sum>30000 && vterm<=28){
				console.log('u6');
				$("#inputDays").val(35);
				$("#inputDaysRange").val(35);
				term=35;
				vterm=35;
				$('#product_1').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');
			}
			// --//-- менее 30000, но время больше 28 дней, передвигаем время на 28
			else if (sum<31000 && vterm>=35){
				console.log('u7');
				$("#inputDays").val(28);
				$("#inputDaysRange").val(28);
				term=28;
				vterm=28;
				$('#product_0').prop('checked', true);
				//productChange();

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_day');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum100');
			}
			else if (sum>30000 && vterm>28){
				console.log('u8');
				$('#product_1').prop('checked', true);
				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_week');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum30');
			}
			else if (sum<30000 && vterm<=28){
				console.log('u9');
				$('#product_0').prop('checked', true);

				$("#colordays").removeClass('__brush_day');
				$("#colordays").removeClass('__brush_week');
				$("#colordays").addClass('__brush_day');

				$("#colorsum").removeClass('__brush_sum30');
				$("#colorsum").removeClass('__brush_sum100');
				$("#colorsum").addClass('__brush_sum100');
			}
*/
		}

		//console.log('sum: '+sum+'; term: '+term+'; vterm: '+vterm);
		//console.log($('input.inputReference:checked').attr('id'));
		if (vterm==35 || vterm==42){
			if (term==42){
				$(".calculator-term-word").text('недели');
				$(".term-type-input_text").html('недели');
			}
			else {
				$(".calculator-term-word").text('недель');
				$(".term-type-input_text").html('недель');
			}
			
			$("input#inputTermType").val("week");
		}
		else {
			$(".term-type-input_text").text('дней');
			$(".calculator-term-word").text('дней');
			$("input#inputTermType").val("day");
		}
		day=mon=0;
		if (vterm==7){
			nterm=7;
			day=7;
		}
		else if (vterm==14){
			nterm=14;
			day=14;
		}
		else if (vterm==21){
			nterm=21;
			day=21;
		}
		else if (vterm==28){
			nterm=28;
			day=28;
		}
		else if (vterm==35){
			nterm=16;
			mon=4;
		}
		else if (vterm==42){
			nterm=24;
			mon=6;
		}
		term=nterm;
		$("#inputDays").val(term);
		$(".calculator-days").text(term);


		var curTermType = $(".inputReference:checked").data('termtypeTerm');
        var curTermTypeRate = $(".inputReference:checked").data('termtypePercent');
        var yearPercent = $(".inputReference:checked").data('yearRate');
        var repaymentType = $(".inputReference:checked").data('repaymentType');
        var intervalPercent = $(".inputReference:checked").data('intervalPercent');
        var inputPercent = $(".inputReference:checked").data('inputpercent');
		
		if (curTermType=='day') term=day;
		else {
			term=mon;
		}

        let psk = 0;
		visioPercent = inputPercent;
		percentMontlyText = "Ежемесячный платеж:";
		percentText = "Процент по кредиту:";		
		if (repaymentType == "Annuity" && window.CPA > 0){
			percentText = "Процент по кредиту от:";
			visioPercent = window.CPA ;	
			percentMontlyText = "Платеж раз в 2 недели:";			
		}
		else if (repaymentType == "InterestOnly" && window.CPIO > 0){
			visioPercent = window.CPIO ;
			percentText = "Процент по кредиту от:";	
			yearPercent	= parseFloat(window.yearDays*window.CPIO);		
		}

		$(".calculator-percent").text(visioPercent);
		$("p#calculator-monthly-payment label.percent-label").text(percentMontlyText);
		$("p.calculator-percent-text label").text(percentText);

        percentConverted = covertPercent(yearPercent, curTermType);

        switch (repaymentType) {
            case 'AtTheEnd':
                total = repaymentAtTheEnd(sum, term, percentConverted);
                break;
            case 'Differential':
                total = repaymentDifferential(sum, term, percentConverted);
                break;
            case 'InterestOnly':
                total = repaymentAtTheEnd(sum, term, percentConverted);
                break;
            case 'Annuity':

                if(intervalPercent && intervalPercent.length) {
                    intervalPercent = intervalPercent.map(v => ({...v, PercentConverted: covertPercent(v.Percent, curTermType)}));
                    total = repaymentAnnuityFloat(sum, term, intervalPercent);
                    psk = calculatePskPercent2(sum, term, intervalPercent);
                } else {
					if (window.CPA == 0){
						total = repaymentAnnuity(sum, term, percentConverted);			
					}
					else{
						monthly = monthlyPaymentAnnuity(sum, nterm);
					}
                }

				if (window.CPA == 0){
					monthly = total/term;					
				}
				else{
					total = monthly * parseFloat(nterm/2).toFixed(0);
				}

                break;
            case 'Standard':
                total = repaymentStandard(sum, term, percentConverted);
                monthly = total/term;
                break;
            default:
                total = repaymentAtTheEnd(sum, term, percentConverted);
                break;
        }

        if(!psk) {
            $(".calculator-psk").parent().hide();
        } else {
            $(".calculator-psk").parent().show();
            $(".calculator-psk").html(psk.toFixed(2) + '%');
        }

        $(".calculator-sum").text(total.toFixed(0));
        $(".calculator-term_type-percent").text(termReferenceShort[curTermTypeRate]);
        $(".calculator-credit_fin_product_name").text($(".inputReference:checked").data('productName'));

        if (monthly && $('#calculator-monthly-payment')) {
            $('.calculator-monthly-payment').text(monthly.toFixed(0));
            $('#calculator-monthly-payment').css('display', 'block');
            if (intervalPercent) {
                $('#calculator-monthly-payment .percent-label').hide();
                $('#calculator-monthly-payment .percent-interval-label').show();
            } else {
                $('#calculator-monthly-payment .percent-label').show();
                $('#calculator-monthly-payment .percent-interval-label').hide();
            }
        } else {
            $('#calculator-monthly-payment').css('display', 'none');
        }
    }

    function covertPercent(yearPercent, curTermType) {
        let percentConverted = 0;
        if (curTermType === 'day') {
            percentConverted = parseFloat((yearPercent / window.yearDays / 100).toFixed(10));
        } else if (curTermType === 'week') {
            percentConverted = parseFloat((yearPercent / 52 / 100).toFixed(10));			
        } else if (curTermType === 'month') {
            percentConverted = parseFloat((yearPercent / 12 / 100).toFixed(10));
        } else if (curTermType === 'year') {
            percentConverted = parseFloat(yearPercent / 100);
        }
        return percentConverted;
    }

    function repaymentAtTheEnd (sum, term, percentConverted) {
        total = sum + (sum * (term * percentConverted));

        return total;
    }

    function repaymentDifferential (sum, term, percentConverted) {
        total = sum + ((sum / 2) * ((term + 1) * percentConverted));

        return total;
    }

    function repaymentStandard (sum, term, percentConverted) {
        termPayment = (sum / term) + ((sum * term * percentConverted) / term);
        total = term * termPayment;

        return total;
    }

    function repaymentAnnuity (sum, term, percentConverted) {
		total = term * sum * percentConverted * ((1 + percentConverted) ** term) / (((1 + percentConverted) ** term) - 1);			
        return total;
    }
	
	function monthlyPaymentAnnuity(sum,nterm){
		var steps = parseFloat(nterm/2).toFixed(0);
		var stavka = (window.CPA*14/100);
		var coeff = (stavka * (1 + stavka) ** steps) / (((1 + stavka) ** steps) - 1);
		return (sum*coeff);
	}

    function repaymentAnnuityFloat (sum, term, intervalPercent) {

        let sumLeft = sum, monthLeft = term, total = 0,
            currentInterval = null, currentIntervalIndex = null, currentMonthlyPayment = 0, currentPercentPayment = 0;
        for(let i = 0; i < term; i++) {
            // находим текущий интервал
            intervalPercent.every((interval, index) => {
                if(i >= interval.TermFrom && (interval.TermTo === 0 || i < interval.TermTo)) {
                    currentInterval = interval;
                    // если тот же интервал, пересчитывать размер ежемесячного платежа не надо
                    if(currentIntervalIndex !== index) {
                        percent = currentInterval.PercentConverted;
                        currentMonthlyPayment = sum * percent * ((1 + percent) ** term) / (((1 + percent) ** term) - 1);
                        currentIntervalIndex = index;
                    }
                    return false;
                }
                return true;
            });
            // проценты за текущий месяц
            currentPercentPayment = sumLeft * currentInterval.PercentConverted;
            // последний платеж, то оплачиваем остаток
            if(monthLeft === 1) {
                currentMonthlyPayment = sumLeft + currentPercentPayment;
            }
            sumLeft = sumLeft - (currentMonthlyPayment - currentPercentPayment);
            total += currentMonthlyPayment;
            monthLeft--;
        }

        return total;
    }

    function calculatePskPercent(sum, term, intervalPercent) {
        let psk = 0,
            pskPercent = 0,
            numDays = 0,
            denominator = 1,
            annuityCoeff = 0,
            annuityPayment = 0,
            sumLeft = sum,
            currentPercentPayment = 0,
            currentMonthlyPayment = 0;
        ;
        let terms = [];

        // заполняем первичными данными
        for(let i = 0; i < term; i++) {

            // дата платежа
            terms.push({
                date: (new Date()).addMonths(i+1)
            });

            // количество дней в периоде
            let prevDate = new Date();
            if (i > 0) {
                prevDate = terms[i - 1].date;
            }
            terms[i].numDays = Math.round((terms[i].date - prevDate) / (24 * 60 * 60 * 1000));
            numDays += terms[i].numDays;

            // находим нужный интервал и ставку за этот интервал
            // пересчитываем месячную ставку исходя из ставки за день и количестве дней в периоде
            intervalPercent.every((interval, index) => {
                if(i >= interval.TermFrom && (interval.TermTo === 0 || i < interval.TermTo)) {
                    //terms[i].monthPercent = +((interval.PercentConverted * 12 / 360) * terms[i].numDays).toFixed(3);
                    terms[i].monthPercent = round((interval.PercentConverted * 12 / 360) * terms[i].numDays, 3);
                    return false;
                }
                return true;
            });
        }

        // считаем коэффициент аннуитета для каждого периода
        for(let i = terms.length - 1; i >= 0; i--) {
            let prevCoeff = 1;
            if(i < (terms.length - 1)) {
                prevCoeff = terms[i+1].coeff;
            }
            //terms[i].coeff = +(prevCoeff * (1 + terms[i].monthPercent)).toFixed(10);
            terms[i].coeff = round(prevCoeff * (1 + terms[i].monthPercent), 10);
            if(i > 0) {
                denominator += terms[i].coeff;
            }
        }
        annuityCoeff = round(terms[0].coeff / denominator, 10);
        annuityPayment = round(sum * annuityCoeff, 2);

        // считаем сумму начисленных процентов и сумму погашения тела кредита
        for(let i = 0; i < term; i++) {
            currentPercentPayment = round(sumLeft * terms[i].monthPercent, 2);
            currentMonthlyPayment = round(Math.min(annuityPayment - currentPercentPayment, sumLeft), 2);
            sumLeft = round(Math.max(sumLeft - currentMonthlyPayment, 0), 2);
            terms[i].annuityPayment = currentPercentPayment + currentMonthlyPayment;
            terms[i].sumLeft = sumLeft;
            psk += terms[i].annuityPayment;
        }

        // считаем ежедневный процент ПСК
        pskPercent = ((psk / sum) - 1) * 100 / numDays;
        // считаем годовой процент ПСК
        pskPercent *= 360;

        return round(pskPercent, 3);
    }

    function calculatePskPercent2(sum, term, intervalPercent) {
        let  pskPercent = 0,
            terms = [];

        // заполняем первичными данными
        for(let i = 0; i < term; i++) {

            terms.push([]);

            // находим нужный интервал и ставку за этот интервал
            // пересчитываем месячную ставку исходя из ставки за день и количестве дней в периоде
            intervalPercent.every((interval, index) => {
                if(i >= interval.TermFrom && (interval.TermTo === 0 || i < interval.TermTo)) {
                    terms[i].monthPercent = interval.PercentConverted;
                    return false;
                }
                return true;
            });

            if(i === 0) {
                terms[i].sumLeft = sum;
            } else {
                terms[i].sumLeft = terms[i - 1].sumLeft - terms[i - 1].monthlyPayment;
            }
            terms[i].percentPayment = round(terms[i].sumLeft * terms[i].monthPercent, 2);
            if(i < term - 1) {
                terms[i].annuityPayment = round(pmt(terms[i].monthPercent, term, sum), 2);
                terms[i].monthlyPayment = terms[i].annuityPayment - terms[i].percentPayment;
            } else {
                terms[i].monthlyPayment = terms[i].sumLeft;
                terms[i].annuityPayment = terms[i].monthlyPayment + terms[i].percentPayment;
            }
        }
        pskPercent = irr(sum, terms.map(value => value.annuityPayment)) * 12;

        return round(pskPercent, 3);
    }

    function pmt(percent, terms, sum) {
        return sum * percent * ((1 + percent) ** terms) / ((1 + percent) ** terms - 1);
    }

    function irr(investment, flow, precision = 0.000001) {

        let sum = flow.reduce(function(previousValue, currentValue){
            return currentValue + previousValue;
        })

        if (sum < investment) {
            return 0;
        }
        let maxIterations = 20, i = 0, min = 0, max = 1, net_present_value = 1, guess = 0;
        if (flow.length) {
            while ((Math.abs(net_present_value - investment) > precision) && (i < maxIterations)) {
                net_present_value = 0;
                guess = (min + max) / 2;
                flow.forEach((cashflow, period) => {
                    net_present_value += cashflow / (1 + guess) ** (period + 1);
                })
                if (net_present_value - investment > 0) {
                    min = guess;
                } else {
                    max = guess;
                }
                i++;
            }
            return guess * 100;
        }

        return 0;
    }

    function clamp(value, min, max) {
        return Math.round(Math.min(Math.max(value, min), max));
    }
    //

    //Калькулятор сбережений
    if ($(".calculator-term_type-percent-deposit").length) {
        var inputSumDeposit = "#inputSumDeposit",
            inputSumRangeDeposit = "#inputSumRangeDeposit",
            inputDaysDeposit = "#inputDaysDeposit",
            inputDaysRangeDeposit = "#inputDaysRangeDeposit",
            inputPercentDeposit = "#inputDepositPercent",
            inputCapitalPercentDeposit = "#inputCapitalDepositPercent",
            inputDepositReference = ".inputDepositReference",
            inputTermTypeDeposit = "#inputTermTypeDeposit",
            inputTermTypePercentDeposit = "#inputTermTypePercentDeposit";

        var minDaysDeposit = $(inputDaysRangeDeposit).attr('min'),
            maxDaysDeposit = $(inputDaysRangeDeposit).attr('max'),
            minSumDeposit = $(inputSumRangeDeposit).attr('min'),
            maxSumDeposit = $(inputSumRangeDeposit).attr('max');

        $(document)
            .on("keyup", inputSumDeposit, function () {
                $(inputSumRangeDeposit).val(clamp(this.value, minSumDeposit, maxSumDeposit));
                calculatorDepositUpdate();
            })
            .on("blur", inputSumDeposit, function () {
                $(this).val(clamp(this.value, minSumDeposit, maxSumDeposit));
                calculatorDepositUpdate();
            })
            .on("input", inputSumRangeDeposit, function () {
                $(inputSumDeposit).val(clamp(this.value, minSumDeposit, maxSumDeposit));
                calculatorDepositUpdate();
            })
            .on("keyup", inputDaysDeposit, function () {
                $(inputDaysRangeDeposit).val(clamp(this.value, minDaysDeposit, maxDaysDeposit));
                calculatorDepositUpdate();
            })
            .on("blur", inputDaysDeposit, function () {
                $(this).val(clamp(this.value, minDaysDeposit, maxDaysDeposit));
                calculatorDepositUpdate();
            })
            .on("input", inputDaysRangeDeposit, function () {
                $(inputDaysDeposit).val(clamp(this.value, minDaysDeposit, maxDaysDeposit));
                calculatorDepositUpdate();
            })

            .on("change", inputCapitalPercentDeposit, function () {
                calculatorDepositUpdate();
            })

            .on("change", inputDepositReference, productDepositChange);

        if ($('#inputDepositPercent').length > 0) {
            productDepositChange();
        }

        if(typeof BX !== 'undefined') {
            BX.addCustomEvent('onAjaxSuccess', calculatorDepositUpdate);
        }
        setTimeout(productDepositChange, 2000);
        setTimeout(calculatorDepositUpdate, 2000);
    }


    function productDepositChange() {
        if (!$(".inputDepositReference:checked").length) {
            $(".inputDepositReference:first").prop('checked', true)
        }
        $product = $(".inputDepositReference:checked");

        minSumDeposit = $product.data('inputsumMin');
        maxSumDeposit = $product.data('inputsumMax');
        minDaysDeposit = $product.data('inputdaysMin');
        maxDaysDeposit = $product.data('inputdaysMax');

        var percent = $product.data('inputpercent'),
            stepSum = (maxSumDeposit - minSumDeposit) / 50,
            stepDays = Math.max((maxDaysDeposit - minDaysDeposit) / 50, 1),
            days = clamp($(inputDaysDeposit).val(), minDaysDeposit, maxDaysDeposit),
            sum = clamp($(inputSumDeposit).val(), minSumDeposit, maxSumDeposit);


        $(inputSumRangeDeposit).attr({ 'min': minSumDeposit, 'max': maxSumDeposit, 'step': stepSum }).val(sum);
        $(inputSumRangeDeposit).siblings('.from').html("от " + minSumDeposit);
        $(inputSumRangeDeposit).siblings('.to').html("до " + maxSumDeposit);
        $(inputDaysRangeDeposit).attr({ 'min': minDaysDeposit, 'max': maxDaysDeposit, 'step': stepDays }).val(days);
        $(inputDaysRangeDeposit).siblings('.from').html("от " + minDaysDeposit);
        $(inputDaysRangeDeposit).siblings('.to').html("до " + maxDaysDeposit);
        $(inputDaysDeposit).val(days);
        $(inputSumDeposit).val(sum);

        $(".calculator-percent-deposit").text(percent);
        $(inputPercentDeposit).val(percent);


        $(inputTermTypeDeposit).val($product.data('termtypeTerm'));
        $(inputTermTypePercentDeposit).val($product.data('termtypePercent'));

        calculatorDepositUpdate();
    }


    function calculatorDepositUpdate() {
        var termReference = {
            'day' : ['день', 'дня', 'дней'],
            'month' : ['месяц', 'месяца', 'месяцев'],
            'year' : ['год', 'года', 'лет'],
        };

        var termReferenceShort = {
            'day' : 'день',
            'month' : 'мес.',
            'year' : 'год',
        };

        var curTermType = $(".inputDepositReference:checked").data('termtypeTerm');
        var curTermTypeRate = $(".inputDepositReference:checked").data('termtypePercent');
        var yearPercent = $(".inputDepositReference:checked").data('yearRate');
        var hasCapitalisation = $(".inputDepositReference:checked").data('capitalisation');
        $(".calculator-fin_product_name").text($(".inputDepositReference:checked").data('productName'));
        var term = $(inputDaysDeposit).val();
        var sum = parseInt($(inputSumDeposit).val());

        if (curTermType == 'day') {
            total = sum + (sum * (term * (yearPercent / window.yearDays / 100)));
            capitalTerm = parseInt(window.yearDays / 30);
        } else if (curTermType == 'month') {
            total = sum + (sum * (term * (yearPercent / 12 / 100)));
            capitalTerm = term;
        } else if (curTermType == 'year') {
            total = sum + (sum * (term * yearPercent / 100));
            capitalTerm = term * 12;
        }

        if ($(inputCapitalPercentDeposit).prop("checked")) {
            total = calcCapital(sum, capitalTerm, yearPercent / 12);
        }

        if (hasCapitalisation == true) {
            $('.capitalisation-block').show();
            $('.capitalisation-block [name="CAPITAL_PERCENT"]').prop("disabled", false);
        } else {
            $('.capitalisation-block').hide();
            $('.capitalisation-block [name="CAPITAL_PERCENT"]').prop("disabled", true);
        }

        $(".calculator-term_type-percent-deposit").text(termReferenceShort[curTermTypeRate]);
        $(".term-type-input_text-deposit").text(termReference[curTermType][2]);
        $(".calculator-days-deposit").text(term);
        $(".calculator-term-word-deposit").text(declensionWord(term, termReference[curTermType]));
        $(".calculator-sum-deposit").text(total.toFixed(0));
    }

    function calcCapital(sum, monthCount, percent) {
        var result = sum;
        for (i = 1; i <= parseInt(monthCount); i++) {
            result = result * ((percent / 100) + 1);
        }

        return parseFloat(result);
    }

    function declensionWord(count, arDeclensions) {
        if (count == 1) {
            return arDeclensions[0];
        } else if (count <= 4) {
            return arDeclensions[1];
        } else if (count > 20 && count % 10 == 1) {
            return arDeclensions[0];
        } else if (count > 20 && count % 10 >= 2 && count % 10 <= 4) {
            return arDeclensions[1];
        } else {
            return arDeclensions[2];
        }
    }
    //

});


