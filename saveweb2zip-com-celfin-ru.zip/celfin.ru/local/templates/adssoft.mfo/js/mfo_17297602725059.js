$(function(){

    <!-- Api Function -->
    jQuery.apiCall = function (params, callback) {
        if(typeof params === 'string' ) {
            params = params+'&csrf='+BX.bitrix_sessid();
        } else {
            params['csrf'] = BX.bitrix_sessid();
        }
        $.post(mfoApiPath, params, function (data) {
            callback(data);
        }, "json")
            .fail(function (xhr, status, error) {
                console.log(xhr.responseText);
            });
    };

    <!-- Custom Bitrix Loader -->
    if(typeof BX !== 'undefined') {
        var waitNodes = [];
        BX.showWait = function (node, msg) {
            node = BX(node) || document.body || document.documentElement;
            waitNodes.push(node.id);
            BX.addClass(node, 'loading');
        };
        BX.closeWait = function (node, obMsg) {
            node = BX(node) || waitNodes.pop() || document.body || document.documentElement;
            BX.removeClass(node, 'loading');
        };
    }


    function onLoad() {
        <!-- If date input not supported -->
        if ($('[type="date"]').prop('type') != 'date') {
            $('[type="date"]').datepicker({dateFormat: 'dd.mm.yy'}).mask('99.99.9999');
        }
        <!-- Phone Input Mask -->
        $('.mask-phone').mask('+7 (999) 999-99-99', {autoclear: false});
    }

    onLoad();

    if(typeof BX !== 'undefined') {
        BX.addCustomEvent('onAjaxSuccess', onLoad);
    }

    if (typeof Cookies.get('ClearStorageUpload') != 'undefined'){
        var FileUploadInStorage = [];
        for(let i=0; i<localStorage.length; i++) {
            let key = localStorage.key(i);
            if (key.indexOf('UPLOAD_') != -1){
                FileUploadInStorage[key] = localStorage.getItem(key);
            }
        }

        if (Object.keys(FileUploadInStorage).length > 0){
            var params = {"method":"clearFileAsyncUpload"};
            for (step in FileUploadInStorage){
                localStorage.removeItem(step);
                params[step] = FileUploadInStorage[step];
            }

            $.apiCall(params, function(response) {
                console.log(response);
            });
        }

        Cookies.remove('ClearStorageUpload');
    }

    if (typeof Cookies.get('TimerResolutionOrder') != 'undefined'){
        if (typeof openTimerLayer == "function"){
            openTimerLayer(Cookies.get('TimerResolutionOrder'));
        }
        Cookies.remove('TimerResolutionOrder');
    }
    else{
        if (typeof clearTimerLayer == "function"){
            clearTimerLayer();
        }        
    }

    function refreshInputs () {
        var calcForm = $(".calculator-form-wrapper");
        var creditInputs = $(".credit-block-controller input:not(.addressSame), .credit-block-controller select");
        var depositInputs = $(".deposit-block-controller input:not(.addressSame), .deposit-block-controller select");

        if ($("#radioCreditRequest").prop('checked')) {
            calcForm.removeClass("deposit-form").addClass("credit-form");
            depositInputs.attr({"disabled" : "disabled"});
            creditInputs.removeAttr("disabled");

            if ($('h1')) {
                $('h1, title').text(window.creditTitle);
            }
        } else {
            calcForm.removeClass("credit-form").addClass("deposit-form");
            creditInputs.attr({"disabled" : "disabled"});
            depositInputs.removeAttr("disabled");
            if ($('h1')) {
                $('h1, title').text(window.depositTitle);
            }
        }

        if ($('[name="LOAN_TYPE"]').val() == 'card_number') {
            $('.bank_account-controller input, .bank_account-controller select').attr({"disabled" : "disabled"});
        } else {
            $('.card_number-controller input, .card_number-controller select').attr({"disabled" : "disabled"});
        }
    }

    $('.js-bank-select').select2({
        width: '100%',
        placeholder: 'Выберите банк',
        language: {
            noResults: function () {
                return "Ничего не найдено";
            }
        }
    });

    $('.mask-passport-series').mask('99 99');
    $('.mask-snils').mask('999-999-999 99');
    $('.mask-card').mask('9999 9999 9999 9999');
    $(".select2-controller").select2();

    $(document)
        //Download File from API
        .on('click', '.file-link', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if(id) {
                window.open(mfoApiPath + '?method=getFile&FILE_ID=' + id + '&csrf='+BX.bitrix_sessid(), '_blank');
            }
        })
        .on('click', '.calculator-radio-wrap', function (e) {
            refreshInputs();
        })
        .on('click', '.smev-waiting', function (e) {
            if ($('[name="confirm_code"]').val()) {
                $('.bx-auth').addClass('loading');
            }
        })
        .on('click', '.link-next-page', function() {
            $(this).addClass('loading');
        });

});
